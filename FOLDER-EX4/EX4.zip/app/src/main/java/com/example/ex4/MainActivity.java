package com.example.ex4;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etMovie, etDirector, etYear;
    Button btnAdd, btnUpdate, btnDelete;
    TableLayout tableLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etMovie = findViewById(R.id.etMovie);
        etDirector = findViewById(R.id.etDirector);
        etYear = findViewById(R.id.etYear);

        btnAdd = findViewById(R.id.btnAdd);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);

        tableLayout = findViewById(R.id.tableLayout);

        btnAdd.setOnClickListener(v -> addMovie());
        btnUpdate.setOnClickListener(v -> updateMovie());
        btnDelete.setOnClickListener(v -> deleteMovie());
    }

    private void addMovie() {
        String movie = etMovie.getText().toString().trim();
        String director = etDirector.getText().toString().trim();
        String year = etYear.getText().toString().trim();

        if (movie.isEmpty()) {
            Toast.makeText(this, "Enter movie name", Toast.LENGTH_SHORT).show();
            return;
        }

        TableRow row = new TableRow(this);

        TextView tvMovie = new TextView(this);
        TextView tvDirector = new TextView(this);
        TextView tvYear = new TextView(this);

        tvMovie.setText(movie);
        tvDirector.setText(director);
        tvYear.setText(year);

        row.addView(tvMovie);
        row.addView(tvDirector);
        row.addView(tvYear);

        tableLayout.addView(row);
        clearFields();
    }

    private void updateMovie() {
        String movie = etMovie.getText().toString().trim();
        boolean found = false;

        for (int i = 1; i < tableLayout.getChildCount(); i++) { // skip header
            TableRow row = (TableRow) tableLayout.getChildAt(i);
            TextView tvMovie = (TextView) row.getChildAt(0);

            if (tvMovie.getText().toString().equalsIgnoreCase(movie)) {
                ((TextView) row.getChildAt(1)).setText(etDirector.getText().toString());
                ((TextView) row.getChildAt(2)).setText(etYear.getText().toString());
                found = true;
                break;
            }
        }

        Toast.makeText(this,
                found ? "Movie updated" : "Movie not found",
                Toast.LENGTH_SHORT).show();

        clearFields();
    }

    private void deleteMovie() {
        String movie = etMovie.getText().toString().trim();
        boolean found = false;

        for (int i = 1; i < tableLayout.getChildCount(); i++) { // skip header
            TableRow row = (TableRow) tableLayout.getChildAt(i);
            TextView tvMovie = (TextView) row.getChildAt(0);

            if (tvMovie.getText().toString().equalsIgnoreCase(movie)) {
                tableLayout.removeViewAt(i);
                found = true;
                break;
            }
        }

        Toast.makeText(this,
                found ? "Movie deleted" : "Movie not found",
                Toast.LENGTH_SHORT).show();

        clearFields();
    }

    private void clearFields() {
        etMovie.setText("");
        etDirector.setText("");
        etYear.setText("");
    }
}