package com.example.ex3;

import android.graphics.*;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ImageView imageView = findViewById(R.id.imageView);

        String shape = getIntent().getStringExtra("shape");
        String color = getIntent().getStringExtra("color");

        if (shape == null || color == null) return;

        Bitmap bitmap = Bitmap.createBitmap(720, 1280, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);

        Paint paint = new Paint();
        paint.setStyle(Paint.Style.FILL);
        paint.setAntiAlias(true);
        paint.setColor(getColor(color));
        paint.setTextSize(40);

        canvas.drawText(shape, 250, 150, paint);
        drawShape(canvas, paint, shape);

        imageView.setImageBitmap(bitmap);
    }

    private void drawShape(Canvas canvas, Paint paint, String shape) {

        switch (shape) {

            case "Rectangle":
                canvas.drawRect(200, 200, 600, 500, paint);
                break;

            case "Square":
                canvas.drawRect(250, 200, 550, 500, paint);
                break;

            case "Circle":
                canvas.drawCircle(400, 350, 150, paint);
                break;

            case "Triangle":
                Path path = new Path();
                path.moveTo(400, 200);
                path.lineTo(200, 500);
                path.lineTo(600, 500);
                path.close();
                canvas.drawPath(path, paint);
                break;

            case "Smiley":
                drawSmiley(canvas, paint);
                break;

            case "House":
                drawHouse(canvas, paint);
                break;

            case "Hexagon":
                drawHexagon(canvas, paint);
                break;
        }
    }

    private void drawSmiley(Canvas canvas, Paint facePaint) {

        canvas.drawCircle(400, 350, 150, facePaint);

        Paint eyePaint = new Paint();
        eyePaint.setColor(Color.RED);
        eyePaint.setStyle(Paint.Style.FILL);
        eyePaint.setAntiAlias(true);

        canvas.drawCircle(350, 320, 15, eyePaint);
        canvas.drawCircle(450, 320, 15, eyePaint);

        Paint smilePaint = new Paint();
        smilePaint.setColor(Color.GREEN);
        smilePaint.setStyle(Paint.Style.STROKE);
        smilePaint.setStrokeWidth(8);
        smilePaint.setAntiAlias(true);

        RectF smileRect = new RectF(330, 330, 470, 430);
        canvas.drawArc(smileRect, 8, 180, false, smilePaint);
    }

    private void drawHouse(Canvas canvas, Paint paint) {

        // House body
        canvas.drawRect(250, 350, 550, 600, paint);

        // Roof
        Paint roofPaint = new Paint();
        roofPaint.setColor(Color.DKGRAY);
        roofPaint.setStyle(Paint.Style.FILL);
        roofPaint.setAntiAlias(true);

        Path roofPath = new Path();
        roofPath.moveTo(400, 250);
        roofPath.lineTo(220, 350);
        roofPath.lineTo(580, 350);
        roofPath.close();

        canvas.drawPath(roofPath, roofPaint);

        // Door
        Paint doorPaint = new Paint();
        doorPaint.setColor(Color.BLACK);
        doorPaint.setStyle(Paint.Style.FILL);

        canvas.drawRect(370, 450, 430, 600, doorPaint);
    }

    private void drawHexagon(Canvas canvas, Paint paint) {

        Path hexagon = new Path();
        hexagon.moveTo(400, 200);
        hexagon.lineTo(520, 270);
        hexagon.lineTo(520, 430);
        hexagon.lineTo(400, 500);
        hexagon.lineTo(280, 430);
        hexagon.lineTo(280, 270);
        hexagon.close();

        canvas.drawPath(hexagon, paint);
    }

    private int getColor(String color) {
        switch (color) {
            case "Red":
                return Color.RED;
            case "Blue":
                return Color.BLUE;
            case "Green":
                return Color.GREEN;
            case "Yellow":
                return Color.YELLOW;
            case "Black":
                return Color.BLACK;
            default:
                return Color.BLACK;
        }
    }
}
